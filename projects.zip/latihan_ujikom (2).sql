-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2023 at 05:11 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latihan_ujikom`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_01_18_070606_create_permission_tables', 1),
(8, '2023_01_26_013714_add_kode_user_to_users_table', 2),
(9, '2023_02_02_014603_create_pakets_table', 2),
(10, '2023_02_02_014742_create_tipe_bayars_table', 2),
(11, '2023_02_02_014851_create_statuses_table', 2),
(12, '2023_02_02_024931_create_transaksis_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(3, 'App\\Models\\User', 73),
(4, 'App\\Models\\User', 60),
(4, 'App\\Models\\User', 65),
(4, 'App\\Models\\User', 66),
(4, 'App\\Models\\User', 67),
(4, 'App\\Models\\User', 70),
(4, 'App\\Models\\User', 72);

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_hari` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `satuan` enum('KG','METER','BUAH') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`id`, `nama`, `jenis`, `jumlah_hari`, `harga`, `satuan`, `created_at`, `updated_at`) VALUES
(1, 'Paket Kilat Semalam', 'Kilat Express', 1, 5000, 'KG', '2023-02-01 19:40:37', '2023-02-01 19:40:37'),
(2, 'Paket Lambat Setahun', 'SiLambat Express', 360, 45000, 'KG', '2023-02-01 19:40:37', '2023-02-01 19:40:37');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'web', '2023-01-24 23:11:48', '2023-01-24 23:11:48'),
(2, 'pemilik', 'web', '2023-01-24 23:11:48', '2023-01-24 23:11:48'),
(3, 'karyawan', 'web', '2023-01-24 23:11:48', '2023-01-24 23:11:48'),
(4, 'konsumen', 'web', '2023-01-24 23:11:48', '2023-01-24 23:11:48');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `nama`, `created_at`, `updated_at`) VALUES
(1, 'BARU', '2023-02-01 19:40:34', '2023-02-01 19:40:34'),
(2, 'DIPROSES', '2023-02-01 19:40:34', '2023-02-01 19:40:34'),
(3, 'SELESAI', '2023-02-01 19:40:34', '2023-02-01 19:40:34'),
(4, 'DIAMBIL', '2023-02-01 19:40:34', '2023-02-01 19:40:34'),
(5, 'BATAL', '2023-02-01 19:40:34', '2023-02-01 19:40:34');

-- --------------------------------------------------------

--
-- Table structure for table `tipe_bayar`
--

CREATE TABLE `tipe_bayar` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tipe_bayar`
--

INSERT INTO `tipe_bayar` (`id`, `nama`, `created_at`, `updated_at`) VALUES
(1, 'BANK', '2023-02-01 19:40:34', '2023-02-01 19:40:34'),
(2, 'Transfer E-Wallet', '2023-02-01 19:40:34', '2023-02-01 19:40:34'),
(3, 'CASH', '2023-02-01 19:40:34', '2023-02-01 19:40:34');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_konsumen` bigint(20) UNSIGNED NOT NULL,
  `id_karyawan` bigint(20) UNSIGNED NOT NULL,
  `paket_id` bigint(20) UNSIGNED NOT NULL,
  `tipe_bayar_id` bigint(20) UNSIGNED NOT NULL,
  `status_id` bigint(20) UNSIGNED NOT NULL,
  `berat` int(11) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `tanggal_keluar` date DEFAULT NULL,
  `status_bayar` tinyint(1) NOT NULL DEFAULT 0,
  `diskon` int(11) NOT NULL DEFAULT 0,
  `total_bayar` int(11) NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `id_konsumen`, `id_karyawan`, `paket_id`, `tipe_bayar_id`, `status_id`, `berat`, `tanggal_masuk`, `tanggal_keluar`, `status_bayar`, `diskon`, `total_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES
(4, 73, 74, 1, 1, 1, 2, '1970-01-01', '1970-01-01', 1, 5, 9500, '{\"kembalian\":\"10000\",\"hutang\":\"0\"}', '2023-02-15 00:29:26', '2023-02-15 00:29:26'),
(8, 67, 73, 2, 2, 1, 3, '1970-01-01', '2024-11-02', 1, 6, 126900, '{\"kembalian\":\"0\",\"hutang\":\"126898\"}', '2023-02-15 19:02:40', '2023-02-15 19:02:40'),
(9, 60, 73, 1, 3, 1, 3, '1970-01-01', '1970-01-01', 0, 6, 14100, '{\"kembalian\":\"0\",\"hutang\":\"14998\"}', '2023-02-15 19:04:05', '2023-02-15 19:04:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `kode_user`, `name`, `email`, `no_telp`, `alamat`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(6, '', 'Jacey Jaskolski', 'tatum62@example.com', '(769) 381-0634', '150 Wilderman Union Suite 465\nNew Katelynnmouth, MD 20769', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '88QkiJCok9', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(7, '', 'ojan', 'emal@gmail.com', '0876574583', 'kukur', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'r6XLa6YBuu', '2023-01-25 00:30:02', '2023-02-01 23:51:09'),
(8, '', 'Herminio Hill', 'daron.treutel@example.com', '352.732.7923', '5216 Heathcote Overpass Apt. 368\nFedericofort, NJ 00920-9568', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '10N4j1iVa2', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(9, '', 'Aryanna Schaefer V', 'robb.walsh@example.net', '(430) 386-6194', '7903 Timothy Shore Apt. 309\nNicolafort, ID 78800-1271', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FjBew6dARe', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(10, '', 'Anabel Ryan', 'lukas77@example.com', '+1-832-635-2797', '7466 Enrique Street\nSouth Johannaview, NH 11483', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'bT0fchAN52', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(11, '', 'Ella Hayes', 'rhowell@example.org', '(301) 790-8449', '50644 Amiya Underpass\nLake Odell, GA 32067-6632', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6Vrfs3mUtR', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(12, '', 'Celestine Bashirian', 'shanon71@example.com', '925-423-5413', '95069 Swift View Apt. 503\nDewittside, NH 02304-5100', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WN3wCaZQNB', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(13, '', 'Dorothy Buckridge', 'kkiehn@example.org', '+1 (603) 705-4378', '4184 Lessie Route Suite 283\nSouth Rafaelahaven, WA 34820-1269', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kLe06y4egF', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(14, '', 'Elfrieda Aufderhar', 'dawson.hoppe@example.net', '+1.757.682.6155', '7166 Jude Prairie\nNorth Burnicestad, VA 88575-7253', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'dVcLaJz9WO', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(15, '', 'Willis Fritsch', 'jacobi.tremayne@example.net', '385.624.7195', '8998 Laron River Apt. 376\nWest Emeliefurt, OH 65719', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ZF85ERBVa6', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(16, '', 'Carli Roberts', 'reichert.lempi@example.org', '(318) 783-6081', '7623 Barton Row Apt. 797\nHackettview, NM 05969', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'BtdZ8AfJ0q', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(17, '', 'Saul Haag', 'keshaun.jacobi@example.net', '1-228-646-3261', '185 Schaden Coves\nNew Luisashire, KS 69954', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '56NWUBldyc', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(18, '', 'Keshawn Jast', 'darien.mraz@example.com', '+1-838-539-1966', '6015 Margaretta Village Apt. 652\nKingborough, WV 70591', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'NUGVGY3on4', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(19, '', 'Faye Krajcik', 'terry.kiarra@example.com', '845.865.6402', '98477 Raynor Bridge\nLake Brandytown, MA 32515', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'NCq7j2NERC', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(20, '', 'Eliane Schoen', 'cbalistreri@example.org', '+1-774-764-5753', '645 Goldner Village\nMylenetown, TX 90514-3181', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'NN7LbWiWXv', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(21, '', 'Mrs. Suzanne Boehm I', 'sienna.larkin@example.com', '480-557-3173', '64258 Glenda Rue Apt. 648\nJaydaburgh, SD 92956-2275', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vp3VT5WlB8', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(22, '', 'Miss Viola Pfeffer Sr.', 'maggio.boyd@example.net', '(580) 446-0502', '207 Rosemary Lodge Apt. 759\nNikitaberg, AZ 33566', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'k3Id9m6qAg', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(23, '', 'Sheila Connelly', 'baumbach.tanya@example.net', '1-661-428-6287', '321 Carli Radial\nSpencerberg, ME 66721', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ly689mrXJF', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(24, '', 'Ms. Kathryn Morissette', 'macey59@example.net', '+14242144039', '6866 Jeffry Burgs\nEast Lucienne, CT 68027-8347', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0BQtWUjmvh', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(25, '', 'Willie Hand', 'gaylord.yadira@example.net', '+18607265555', '468 Nitzsche Squares\nSmithburgh, OR 32888-3989', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SYDgY80hzC', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(26, '', 'Ms. Rhea Kutch', 'joany79@example.net', '+1-321-883-1977', '5850 Euna Courts Suite 619\nSilasfort, GA 99175-3929', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Z8lDVFox8e', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(27, '', 'Belle Hand', 'wkozey@example.com', '(364) 818-1962', '277 Greenholt Circles Suite 394\nMonahanport, MO 67181-4648', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'oU3Sa5R25x', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(28, '', 'Gerald Schaefer II', 'enrique.jacobi@example.com', '480-666-8087', '39943 Torey Mews Suite 786\nMicheleburgh, IA 38059-3045', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'fOFepMsQEd', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(29, '', 'Gordon Senger', 'nathaniel.rippin@example.com', '1-878-686-1814', '38876 Gutmann Plaza Apt. 688\nNorth Osvaldo, OH 35167-3646', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'gF9TRwKY7Z', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(30, '', 'Jeramie Gerhold', 'elisha.bayer@example.org', '+1.857.414.4376', '1650 Waters Wall\nNorth Adriantown, LA 37145', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8qs9CE3E4D', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(31, '', 'Tierra Mraz MD', 'okon.sister@example.com', '+16417552235', '701 Helena Heights\nRudyborough, DE 64100-3519', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WtqYHJNA2L', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(32, '', 'Prof. Enid Jenkins', 'alexandrea28@example.net', '914-359-6392', '4289 Kolby Summit Suite 780\nNew Wilhelmineport, WA 67498', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'uOm2T4RchN', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(33, '', 'Fernando Grady', 'gianni18@example.com', '+1-743-510-9254', '4812 Renner Stravenue\nSouth Lesly, GA 24510-6577', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ROSeV8ZUtP', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(34, '', 'Josianne Simonis', 'gkutch@example.net', '+1.385.277.6169', '204 Trycia Plains\nEast Lilyan, CO 80020-9736', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FW4eEu1018', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(35, '', 'Imani Ebert', 'thalia.hodkiewicz@example.org', '608.505.0935', '57844 Gwendolyn Pines Suite 109\nWilliamsonburgh, WA 18381-5025', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 's3ehIX5a3z', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(36, '', 'Hertha Kulas I', 'rozella49@example.com', '785-896-8574', '62274 Kassulke Hills Suite 774\nNorth Darren, IL 43069-9025', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'S1MHWm2UST', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(37, '', 'Dr. Alejandrin Heathcote I', 'mitchell.duncan@example.org', '+18654244850', '12509 Octavia Glens\nSouth Veldamouth, AK 18574', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'dAY28pyvhP', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(38, '', 'Ms. Annamae Erdman', 'seamus53@example.com', '910.339.3532', '986 Clementina Points Apt. 343\nJustynside, MS 65206', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'JFepikwefe', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(39, '', 'Golden Gibson', 'alessandro70@example.net', '+1 (779) 912-0233', '49433 Jaunita Brook\nKleinside, TX 36885-2059', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'brUnhNcoi6', '2023-01-25 00:30:02', '2023-01-25 00:30:02'),
(40, '', 'Norene Hettinger', 'lwillms@example.org', '+1 (956) 662-3252', '821 Pouros Brook\nJasminport, ME 87057', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'fFzRAeM2Ze', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(41, '', 'Lacey Wilkinson III', 'ashly11@example.com', '940-646-0590', '71286 Zulauf Drives\nEuniceside, AL 34495', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'tbEdnAJNaR', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(42, '', 'Dr. Vincent Bosco', 'xkovacek@example.com', '253-263-5480', '2875 Jacobi Cove Apt. 267\nVladimirmouth, NY 24508', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ChdWS8ZWxJ', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(43, '', 'Mr. Jalon Gulgowski DVM', 'ycorkery@example.org', '704-665-0484', '7301 Ernie Court Suite 193\nRathstad, MD 97319-1126', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kbeSabdXIL', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(44, '', 'Leta Hirthe', 'tania01@example.com', '(786) 771-9774', '2748 Oral Courts\nSouth Biankashire, KY 65837-8213', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'KTynN8H1iL', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(45, '', 'Judge Durgan DDS', 'octavia.schroeder@example.net', '323-778-3344', '50403 Betty Hills Suite 965\nNorth Karson, NM 73533-6560', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6Fy3w9pJoz', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(46, '', 'Miss Ella Rosenbaum PhD', 'adell.trantow@example.net', '+1 (743) 960-9142', '45179 Johnston Field Apt. 792\nLake Greg, MN 55524', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8ZKDgwINJG', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(47, '', 'Lenora Kling', 'bcollier@example.org', '321-477-9006', '69052 Hanna Road\nPort Damarismouth, IL 65313', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ja4MSVXG7M', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(48, '', 'Talia Larkin', 'keebler.sophia@example.com', '534.298.0716', '6606 Dicki Fort\nLake Metabury, TN 54425', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4ywuR1B4xf', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(49, '', 'Collin Hermann', 'micaela22@example.com', '+14423696961', '7250 Yesenia Court\nNew Shanon, AK 75665', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FRSAusY3hp', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(50, '', 'Edmond Williamson PhD', 'louisa.ullrich@example.org', '+1-425-396-0669', '773 Kulas Branch\nNew Jaycefort, NH 62814', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Kw77GCi3jn', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(51, '', 'Glennie Gleichner Sr.', 'ludwig.bechtelar@example.net', '310-971-6478', '83757 Gussie Roads Suite 550\nKassandraland, WA 11180-9736', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'AyZS3GLMiI', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(52, '', 'Kelsie Pacocha', 'lhoppe@example.org', '947.276.0574', '368 Reichert Island\nLittelfurt, MT 11778', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'W61x5ILLD6', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(53, '', 'Albina Dietrich II', 'ewhite@example.com', '1-254-608-0907', '48826 Rosenbaum Circles Suite 244\nAbbottfurt, TN 25298-8798', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'exfVFodpWm', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(54, '', 'Pearlie Nicolas DDS', 'koelpin.bradley@example.com', '(479) 726-0645', '68222 Brannon Locks\nSouth Krystina, AZ 59163-9250', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6pFGatzQJI', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(55, '', 'Johnson Buckridge', 'hodkiewicz.renee@example.net', '440-235-2762', '20714 Rosenbaum Summit\nKonopelskifort, WY 75348-8637', '2023-01-25 00:30:02', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'tGUsbjynK7', '2023-01-25 00:30:03', '2023-01-25 00:30:03'),
(60, 'KNSMN0002', 'kui', 'marks@example.net', '0897675787', 'rtrtrtr', NULL, 'NOTASSIGN', NULL, '2023-01-26 00:01:14', '2023-01-26 00:01:14'),
(65, 'KNSMN0003', 'erge', 'kanadahulia31@gmail.com', '087894545764', 'ererertyt', NULL, 'NOTASSIGN', NULL, '2023-01-26 00:12:49', '2023-01-26 00:12:49'),
(66, 'KNSMN0004', 'oijuou', 'gASTYAf', '087656444', 'sdfsge', NULL, 'NOTASSIGN', NULL, '2023-01-26 00:19:59', '2023-01-26 00:19:59'),
(67, 'KNSMN0005', 'jalu giri', 'Aepsapruding@gmail.com', '08984674834', 'hahah', NULL, 'NOTASSIGN', NULL, '2023-01-31 21:17:18', '2023-01-31 21:17:18'),
(70, 'KNSMN0006', 'Aep', '14-3207011003221@pps', '0896758548', 'tagtag', NULL, 'NOTASSIGN', NULL, '2023-01-31 21:18:40', '2023-01-31 21:18:40'),
(73, 'KRY-0001', 'ehan', 'karyawan@laundry.com', '087894456868', 'Jln. sudirman No.269', NULL, '$2y$10$T69VFAv8wZcxqN0e0T483ORdY.L4aUJq7E1Gp.eCg8KksiKinGHCC', NULL, '2023-02-09 00:56:54', '2023-02-09 00:56:54'),
(74, 'KNSM0070', 'efe', 'hehoha@gmail.com', '098676687', 'wfdwf', NULL, 'NOTASSIGN', NULL, '2023-02-08 21:54:51', '2023-02-08 21:54:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tipe_bayar`
--
ALTER TABLE `tipe_bayar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tipe_bayar`
--
ALTER TABLE `tipe_bayar`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
