<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransaksisTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaksi', function (Blueprint $table) {
            $table->id();
            $table->foreignidFor(App\Models\User::class, 'id_konsumen');
            $table->foreignidFor(App\Models\User::class, 'id_karyawan', );

            $table->foreignidFor(App\Models\Paket::class);
            $table->foreignidFor(App\Models\TipeBayar::class);
            $table->foreignidFor(App\Models\Status::class);

            $table->integer('berat');
            $table->date('tanggal_masuk');
            $table->date('tanggal_keluar')->nullable();
            $table->boolean('status_bayar')->default(false);
            $table->integer('diskon')->default(0);
            $table->integer('total_bayar');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaksi');
    }
}
