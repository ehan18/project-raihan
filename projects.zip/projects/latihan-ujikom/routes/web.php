<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\laporanController;
use App\Http\Controllers\karyawanController;
use App\Http\Controllers\KonsumenController;
use App\Http\Controllers\TransaksiController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware('auth')->group(function(){
    Route::get('/dashboard', function (){
        return view('dashboard.index');
});
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::get('/konsumen', [KonsumenController::class, 'index'])->name('konsumen.index');
    Route::get('/karyawan', [karyawanController::class, 'index'])->name('karyawan.index');
        
    Route::get('/konsumen/create', [KonsumenController::class, 'create'])->name('konsumen.create');
    Route::post('/konsumen/store', [KonsumenController::class, 'store'])->name('konsumen.store');
    Route::get('/konsumen/edit/{user}', [KonsumenController::class, 'edit'])->name('konsumen.edit');
    Route::patch('/konsumen/update/{user}', [KonsumenController::class, 'update'])->name('konsumen.update');
    Route::delete('/konsumen/destroy{user}', [KonsumenController::class,'destroy'])->name('konsumen.destroy');
        
    Route::get('/karyawan/create', [KaryawanController::class, 'create'])->name('karyawan.create');
    Route::post('/karyawan/store', [KaryawanController::class, 'store'])->name('karyawan.store');
    Route::get('/karyawan/edit/{user}', [karyawanController::class, 'edit'])->name('karyawan.edit');
    Route::patch('/karyawan/update/{user}', [KaryawanController::class, 'update'])->name('karyawan.update');
    Route::delete('/karyawan/destroy{user}', [KaryawanController::class,'destroy'])->name('karyawan.destroy');
        
    Route::get('/transaksi', [TransaksiController::class, 'index'])->name('transaksi.index');
    Route::get('/transaksi/create', [TransaksiController::class, 'create'])->name('transaksi.create');
    Route::post('/transaksi/store', [TransaksiController::class, 'store'])->name('transaksi.store');
    Route::delete('/transaksi/destroy/{transaksi}', [TransaksiController::class, 'destroy'])->name('transaksi.destroy');

    Route::get('/laporan/transaksi', [laporanController::class, 'lap_transaksi'])->name('laporan.transaksi');
    Route::post('/laporan/transaksi/ajax', [laporanController::class, 'lap_transaksi_ajax'])->name('laporan.transaksi.ajax');
});

Route::get('/', function () {
    return view('welcome');
});

Route::get('/index', function (){
    return view('index');
});



Route::get('/index', function (){
    return view('index');
});


Auth::routes();
