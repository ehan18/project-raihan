<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TipeBayarController extends Controller
{
    //
}
